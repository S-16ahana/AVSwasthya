package com.healthcare.emailverification.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import com.healthcare.emailverification.entity.OtpVerification;
import java.util.Optional;

public interface OtpVerificationRepository extends JpaRepository<OtpVerification, Long> {
    Optional<OtpVerification> findTopByEmailOrderByCreatedAtDesc(String email);
}