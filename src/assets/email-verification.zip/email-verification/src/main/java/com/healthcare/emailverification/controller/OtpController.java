package com.healthcare.emailverification.controller;

import com.healthcare.emailverification.service.OtpService;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/otp")
@CrossOrigin(origins = "http://localhost:3000")
public class OtpController {

    private final OtpService otpService;

    public OtpController(OtpService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/send")
    public String sendOtp(@RequestBody Map<String, String> payload) throws IOException {
        String email = payload.get("email");
        otpService.generateAndSendOtp(email);
        return "OTP sent";
    }

    @PostMapping("/verify")
    public boolean verifyOtp(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String otp = payload.get("otp");
        return otpService.verifyOtp(email, otp);
    }
}
