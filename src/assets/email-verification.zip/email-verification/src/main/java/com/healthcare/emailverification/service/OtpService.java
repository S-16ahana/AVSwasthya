package com.healthcare.emailverification.service;

import com.healthcare.emailverification.entity.OtpVerification;
import com.healthcare.emailverification.repo.OtpVerificationRepository;
import com.sendgrid.*;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class OtpService {

    private final OtpVerificationRepository otpRepo;

    @Value("${sendgrid.api-key}")
    private String sendGridApiKey;

    public OtpService(OtpVerificationRepository otpRepo) {
        this.otpRepo = otpRepo;
    }

    public String generateAndSendOtp(String email) throws IOException {
        String otp = String.format("%06d", new Random().nextInt(999999));

        OtpVerification otpEntry = new OtpVerification();
        otpEntry.setEmail(email);
        otpEntry.setOtp(otp);
        otpEntry.setCreatedAt(LocalDateTime.now());
        otpRepo.save(otpEntry);

        sendEmail(email, otp);
        return otp;
    }

    private void sendEmail(String toEmail, String otp) throws IOException {
        Email from = new Email("veeresh@avsofttechnologies.in");
        Email to = new Email(toEmail);
        String subject = "Your OTP Verification Code";
        Content content = new Content("text/plain", "Your OTP code is: " + otp);
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid(sendGridApiKey);
        Request request = new Request();

        request.setMethod(Method.POST);
        request.setEndpoint("mail/send");
        request.setBody(mail.build());

        Response response = sg.api(request);
        System.out.println(response.getStatusCode());
        System.out.println(response.getBody());
        System.out.println(response.getHeaders());
    }

    public boolean verifyOtp(String email, String enteredOtp) {
        Optional<OtpVerification> otpOptional = otpRepo.findTopByEmailOrderByCreatedAtDesc(email);

        return otpOptional.filter(otp -> !otp.isVerified()
                && otp.getOtp().equals(enteredOtp)
                && otp.getCreatedAt().plusMinutes(5).isAfter(LocalDateTime.now()))
                .map(otp -> {
                    otp.setVerified(true);
                    otpRepo.save(otp);
                    return true;
                }).orElse(false);
    }
}
